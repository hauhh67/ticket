-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 11, 2017 at 03:57 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ticket`
--

-- --------------------------------------------------------

--
-- Table structure for table `ages`
--

CREATE TABLE IF NOT EXISTS `ages` (
  `age_id` int(11) NOT NULL AUTO_INCREMENT,
  `age_name` varchar(10) NOT NULL,
  PRIMARY KEY (`age_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ages`
--

INSERT INTO `ages` (`age_id`, `age_name`) VALUES
(1, '< 20'),
(2, '20-30'),
(3, '30-40'),
(4, '40-50'),
(5, '> 50');

-- --------------------------------------------------------

--
-- Table structure for table `bands`
--

CREATE TABLE IF NOT EXISTS `bands` (
  `band_id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie_id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`band_id`),
  KEY `fk_bands_categories1_idx` (`categorie_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `bands`
--

INSERT INTO `bands` (`band_id`, `categorie_id`, `name`, `owner_id`) VALUES
(2, 4, 'Band Test', 1),
(3, 14, 'hau test new bands', 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `categorie_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`categorie_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categorie_id`, `parent_id`, `name`) VALUES
(1, NULL, 'MUSIC'),
(2, 1, 'Alternative Music'),
(3, 1, 'Blues'),
(4, 1, 'Classical Music'),
(5, 1, 'Country '),
(6, 1, 'Dance '),
(7, 1, 'Easy Listening'),
(8, 1, 'Electronic '),
(9, 1, 'European Music (Folk / Pop)'),
(10, 1, 'Hip Hop / Rap'),
(11, 1, 'Indie Pop'),
(12, 1, 'Inspirational (incl. Gospel)'),
(13, 1, 'Asian Pop (J-Pop, K-pop)'),
(14, 1, 'Jazz'),
(15, 1, 'Latin Music'),
(16, 1, 'New Age'),
(17, 1, 'Opera'),
(18, 1, 'Pop (Popular music)'),
(19, 1, 'R&B / Soul'),
(20, 1, 'Reggae'),
(21, 1, 'Rock'),
(22, 1, 'Singer / Songwriter (inc; Folk)'),
(23, 1, 'World Music / Beats'),
(24, NULL, 'DRAMATIC'),
(25, 24, 'SUB DRAMATIC SUB DRAMATIC SUB DRAMATIC');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `county_id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`city_id`),
  KEY `fk_city_countries1_idx` (`county_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `county_id`, `name`) VALUES
(8, 1, 'Hồ Chí Minh'),
(9, 1, 'Hà Nội'),
(10, 1, 'Đà Nẵng'),
(11, 1, 'Cần Thơ'),
(12, 1, 'Hải Phòng'),
(13, 1, 'Khánh Hòa'),
(14, 1, 'Bà Rịa Vũng Tàu'),
(15, 1, 'Đồng Nai'),
(16, 1, 'Đăk Lăk'),
(17, 1, 'An Giang'),
(18, 1, 'Bắc Giang'),
(19, 1, 'Bắc Kạn'),
(20, 1, 'Bạc Liêu'),
(21, 1, 'Bình Dương'),
(22, 1, 'Bình Phước'),
(23, 1, 'Bình Thuận'),
(24, 1, 'Bình Định'),
(25, 1, 'Bắc Ninh'),
(26, 1, 'Cà Mau'),
(27, 1, 'Cao Bằng'),
(28, 1, 'Bến Tre'),
(29, 1, 'Đăk Nông'),
(30, 1, 'Điện Biên'),
(31, 1, 'Đồng Tháp'),
(32, 1, 'Gia Lai'),
(33, 1, 'Hà Giang'),
(34, 1, 'Hà Nam'),
(35, 1, 'Hà Tĩnh'),
(36, 1, 'Hải Dương'),
(37, 1, 'Hậu Giang'),
(38, 1, 'Hòa Bình'),
(39, 1, 'Hưng Yên'),
(40, 1, 'Kiên Giang'),
(41, 1, 'Kon Tum'),
(42, 1, 'Lai Châu'),
(43, 1, 'Lâm Đồng'),
(44, 1, 'Lạng Sơn'),
(45, 1, 'Lào Cai'),
(46, 1, 'Long An'),
(47, 1, 'Nam Định'),
(48, 1, 'Nghệ An'),
(49, 1, 'Ninh Bình'),
(50, 1, 'Ninh Thuận'),
(51, 1, 'Phú Thọ'),
(52, 1, 'Phú Yên'),
(53, 1, 'Quảng Bình'),
(54, 1, 'Quảng Nam'),
(55, 1, 'Quảng Ngãi'),
(56, 1, 'Quảng Ninh'),
(57, 1, 'Quảng Trị'),
(58, 1, 'Sóc Trăng'),
(59, 1, 'Sơn La'),
(60, 1, 'Tây Ninh'),
(61, 1, 'Thái Bình'),
(62, 1, 'Thái Nguyên'),
(63, 1, 'Thanh Hóa'),
(64, 1, 'Thừa Thiên Huế'),
(65, 1, 'Tiền Giang'),
(66, 1, 'Trà Vinh'),
(67, 1, 'Tuyên Quang'),
(68, 1, 'Vĩnh Long'),
(69, 1, 'Vĩnh Phúc'),
(70, 1, 'Yên Bái'),
(71, 1, 'Nha Trang');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `county_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`county_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`county_id`, `name`) VALUES
(1, 'Viet Nam');

-- --------------------------------------------------------

--
-- Table structure for table `email_template`
--

CREATE TABLE IF NOT EXISTS `email_template` (
  `email_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` varchar(5000) NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`email_template_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `email_template`
--

INSERT INTO `email_template` (`email_template_id`, `name`, `subject`, `content`, `owner_id`) VALUES
(10, 'Order confirmation  (VN)', 'Cảm ơn bạn đã đặt vé trên PDV !', '<p>Xin Ch&agrave;o<strong> {ORDER_NAME}</strong></p>\r\n<p>Cảm ơn bạn đ&atilde; đặt v&eacute; tr&ecirc;n PDV!</p>\r\n<p>V&eacute; của bạn sẽ được gửi đến bạn trong v&ograve;ng 1-3 ng&agrave;y l&agrave;m việc.</p>\r\n<p>Nếu bạn c&oacute; bất kỳ c&acirc;u hỏi hoặc quan t&acirc;m, xin vui l&ograve;ng li&ecirc;n hệ <a href="mailto:info@poussieresdevie.org">info@poussieresdevie.org</a></p>\r\n<p>Xin Cảm ơn !</p>\r\n<p><strong>Poussi&egrave;res de Vie</strong></p>\r\n<p><img src="http://app.vietnam-team.com/ticket/images/tinymce-upload/6681e1c5167f1635b9437417039e70f8.jpg" alt="" height="100" /></p>\r\n<table style="width: 80%; margin-left: auto; margin-right: auto;" width="100%">\r\n<tbody>\r\n<tr>\r\n<td>&nbsp;</td>\r\n<td style="text-align: center;"><span style="font-size: 18pt;"><strong>BOOKING INFORMATION</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td>&nbsp;</td>\r\n<td>\r\n<p>Order ID:&nbsp;<strong>{ORDER_ID},&nbsp;</strong>Order date:&nbsp;<strong>{ORDER_DATE}</strong></p>\r\n<p>Name:&nbsp;<strong>{ORDER_NAME}</strong></p>\r\n<p>Email:&nbsp;<strong>{ORDER_EMAIL}</strong></p>\r\n<p>Address: &nbsp;<strong>{ORDER_ADDRESS}</strong></p>\r\n<p>Telephone<strong>:&nbsp;<strong>{ORDER_TELEPHONE}</strong></strong></p>\r\n<p>Total amount:&nbsp;<strong>{ORDER_TOTAL}</strong></p>\r\n<p>Note:<strong>&nbsp;</strong><strong>{ORDER_NOTES}</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>Order&nbsp;details:</strong></p>\r\n<p><strong>{ORDER_ITEMS}</strong></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p><strong>&nbsp;</strong></p>', 56),
(11, 'Order comfirmation (EN)', 'Thank you for your booking!', '<p>Dear&nbsp;<strong>{ORDER_NAME}</strong></p>\r\n<p>Thanks for your booking on the PdV ticketing portal.</p>\r\n<p>Your tickets will be delivered to you within 1-3 working days.</p>\r\n<p>If you have any questions or concerns, please contact &nbsp;<a href="mailto:info@poussieresdevie.org">info@poussieresdevie.org</a></p>\r\n<p>Thank you!</p>\r\n<p><strong>Poussieres de Vie &nbsp;</strong></p>\r\n<p><strong><img src="http://app.vietnam-team.com/ticket/images/tinymce-upload/6681e1c5167f1635b9437417039e70f8.jpg" alt="" height="100" /><br /></strong></p>\r\n<p>&nbsp;</p>\r\n<table style="width: 80%; margin-left: auto; margin-right: auto;" width="100%">\r\n<tbody>\r\n<tr>\r\n<td>&nbsp;</td>\r\n<td style="text-align: center;"><span style="font-size: 18pt;"><strong>BOOKING CONFIRMATION</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td>&nbsp;</td>\r\n<td>\r\n<p>Order ID:&nbsp;<strong>{ORDER_ID},&nbsp;</strong>Order date:&nbsp;<strong>{ORDER_DATE}</strong></p>\r\n<p>Name:&nbsp;<strong>{ORDER_NAME}</strong></p>\r\n<p>Email:&nbsp;<strong>{ORDER_EMAIL}</strong></p>\r\n<p>Address: &nbsp;<strong>{ORDER_ADDRESS}</strong></p>\r\n<p>Telephone<strong>:&nbsp;<strong>{ORDER_TELEPHONE}</strong></strong></p>\r\n<p>Total amount:&nbsp;<strong>{ORDER_TOTAL}</strong></p>\r\n<p>Note:<strong>&nbsp;</strong><strong>{ORDER_NOTES}</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>Order&nbsp;details:</strong></p>\r\n<p><strong>{ORDER_ITEMS}</strong></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>', 56);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie_id` int(11) DEFAULT NULL,
  `band_id` int(11) DEFAULT NULL,
  `schema_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'is owner_id',
  `name` varchar(100) DEFAULT NULL,
  `date_begin` date NOT NULL,
  `date_end` date NOT NULL,
  `bloc_html` text,
  `bloc_html2` text,
  `image` mediumblob,
  PRIMARY KEY (`event_id`),
  KEY `fk_events_users_idx` (`user_id`),
  KEY `fk_events_bands1_idx` (`band_id`),
  KEY `fk_events_schemas1_idx` (`schema_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `events`
--


-- --------------------------------------------------------

--
-- Table structure for table `method_payment`
--

CREATE TABLE IF NOT EXISTS `method_payment` (
  `method_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`method_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `method_payment`
--

INSERT INTO `method_payment` (`method_id`, `name`) VALUES
(1, 'Cash On Delivery'),
(2, 'Payment Online');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `method_id` int(11) NOT NULL DEFAULT '1',
  `name` varchar(45) NOT NULL,
  `date_order` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(45) NOT NULL,
  `add_street` varchar(50) DEFAULT NULL,
  `add_city_id` int(11) DEFAULT NULL,
  `add_country_id` int(11) DEFAULT NULL,
  `telephone` varchar(20) NOT NULL,
  `total` decimal(10,0) DEFAULT NULL,
  `notes` varchar(1000) DEFAULT NULL,
  `paid` tinyint(1) NOT NULL DEFAULT '0',
  `date_paid` datetime DEFAULT NULL,
  `owner_id` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `delivered_by` int(11) DEFAULT NULL,
  `order_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`order_id`),
  KEY `fk_orders_users1_idx` (`user_id`),
  KEY `add_city_id` (`add_city_id`),
  KEY `add_country_id` (`add_country_id`),
  KEY `owner_id` (`owner_id`),
  KEY `updated_by` (`updated_by`,`delivered_by`,`order_status`),
  KEY `order_status` (`order_status`),
  KEY `delivered_by` (`delivered_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `orders`
--


--
-- Triggers `orders`
--
DROP TRIGGER IF EXISTS `orders_AUPD`;
DELIMITER //
CREATE TRIGGER `orders_AUPD` AFTER UPDATE ON `orders`
 FOR EACH ROW -- Edit trigger body code below this line. Do not edit lines above this one
begin
	call update_ticket_when_update_order(NEW.order_id);

end
//
DELIMITER ;
DROP TRIGGER IF EXISTS `orders_BDEL`;
DELIMITER //
CREATE TRIGGER `orders_BDEL` BEFORE DELETE ON `orders`
 FOR EACH ROW -- Edit trigger body code below this line. Do not edit lines above this one
begin
	call reset_ticket_when_delete_order(OLD.`order_id`);
end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE IF NOT EXISTS `order_items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `fk_order_items_orders1_idx` (`order_id`),
  KEY `fk_order_items_tickets1_idx` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `order_items`
--


--
-- Triggers `order_items`
--
DROP TRIGGER IF EXISTS `order_items_BDEL`;
DELIMITER //
CREATE TRIGGER `order_items_BDEL` BEFORE DELETE ON `order_items`
 FOR EACH ROW -- Edit trigger body code below this line. Do not edit lines above this one
begin
	call reset_ticket_when_delete_order_item(OLD.`ticket_id`);
end
//
DELIMITER ;
DROP TRIGGER IF EXISTS `order_items_ADEL`;
DELIMITER //
CREATE TRIGGER `order_items_ADEL` AFTER DELETE ON `order_items`
 FOR EACH ROW -- Edit trigger body code below this line. Do not edit lines above this one
begin
	call update_order_total_when_delete_order_items(OLD.`order_id`);
end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE IF NOT EXISTS `order_status` (
  `order_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`order_status_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `order_status`
--

INSERT INTO `order_status` (`order_status_id`, `name`) VALUES
(1, 'Pending'),
(2, 'Delivery'),
(3, 'Done');

-- --------------------------------------------------------

--
-- Table structure for table `order_template`
--

CREATE TABLE IF NOT EXISTS `order_template` (
  `order_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` varchar(5000) NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`order_template_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `order_template`
--

INSERT INTO `order_template` (`order_template_id`, `name`, `subject`, `content`, `owner_id`) VALUES
(4, 'Order Details', 'Template for print order to page', '<table style="width: 80%; margin-left: auto; margin-right: auto;" width="100%">\r\n<tbody>\r\n<tr>\r\n<td><img style="float: right;" src="http://app.vietnam-team.com/ticket/images/tinymce-upload/6681e1c5167f1635b9437417039e70f8.jpg" alt="" height="100" /></td>\r\n<td style="text-align: center;"><span style="font-size: 18pt;"><strong>TICKET RESERVATION</strong></span></td>\r\n</tr>\r\n<tr>\r\n<td>&nbsp;</td>\r\n<td>\r\n<p>Order ID:&nbsp;<strong>{ORDER_ID},&nbsp;</strong>Order date:&nbsp;<strong>{ORDER_DATE}</strong></p>\r\n<p>Name:&nbsp;<strong>{ORDER_NAME}</strong></p>\r\n<p>Email:&nbsp;<strong>{ORDER_EMAIL}</strong></p>\r\n<p>Address: &nbsp;<strong>{ORDER_ADDRESS}</strong></p>\r\n<p>Telephone<strong>:&nbsp;<strong>{ORDER_TELEPHONE}</strong></strong></p>\r\n<p>Total amount:&nbsp;<strong>{ORDER_TOTAL}</strong></p>\r\n<p>Note:<strong>&nbsp;</strong><strong>{ORDER_NOTES}</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>Order&nbsp;details:</strong></p>\r\n<p><strong>{ORDER_ITEMS}</strong></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>', 56);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE IF NOT EXISTS `schedules` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `date_begin` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`schedule_id`),
  KEY `fk_schedules_events1_idx` (`event_id`),
  KEY `opened` (`opened`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `schedules`
--


--
-- Triggers `schedules`
--
DROP TRIGGER IF EXISTS `schedules_AUPD`;
DELIMITER //
CREATE TRIGGER `schedules_AUPD` AFTER UPDATE ON `schedules`
 FOR EACH ROW BEGIN
	if (OLD.opened=0 && NEW.opened=1) then
	  call create_ticket_for_schedule(NEW.schedule_id);
	end if;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `schemas`
--

CREATE TABLE IF NOT EXISTS `schemas` (
  `schema_id` int(11) NOT NULL AUTO_INCREMENT,
  `theater_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `image` mediumblob,
  `note` varchar(255) DEFAULT NULL,
  `is_circle_seat` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`schema_id`),
  KEY `fk_schemas_theaters1_idx` (`theater_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `schemas`
--


-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE IF NOT EXISTS `seats` (
  `seat_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) NOT NULL,
  `row_num` varchar(45) DEFAULT NULL,
  `seat_num` varchar(45) DEFAULT NULL,
  `keys` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`seat_id`),
  KEY `fk_seats_zones1_idx` (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `seats`
--


-- --------------------------------------------------------

--
-- Table structure for table `ship_location`
--

CREATE TABLE IF NOT EXISTS `ship_location` (
  `ship_location_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) NOT NULL,
  `ship_price` float NOT NULL DEFAULT '0',
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`ship_location_id`),
  KEY `city_id` (`city_id`,`owner_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `ship_location`
--

INSERT INTO `ship_location` (`ship_location_id`, `city_id`, `ship_price`, `owner_id`) VALUES
(68, 8, 0, 56);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `TaskID` varchar(255) NOT NULL,
  `Done` tinyint(4) NOT NULL DEFAULT '0',
  `Params` text,
  `Status` int(11) NOT NULL DEFAULT '0',
  `Result` varchar(255) DEFAULT NULL,
  `D_Maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`TaskID`),
  KEY `Done` (`Done`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`TaskID`, `Done`, `Params`, `Status`, `Result`, `D_Maj`) VALUES
('9529m8aqc15p8j5bbmfkr41gp6', 1, NULL, 100, '2', '2015-09-22 17:13:26'),
('9m025aogm9ms8gl6asibcjgda0', 1, NULL, 100, '1', '2016-03-24 16:14:12');

-- --------------------------------------------------------

--
-- Table structure for table `theaters`
--

CREATE TABLE IF NOT EXISTS `theaters` (
  `theater_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `add_street` varchar(50) DEFAULT NULL,
  `add_city_id` int(11) DEFAULT NULL,
  `add_country_id` int(11) DEFAULT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`theater_id`),
  KEY `owner_id` (`owner_id`),
  KEY `add_city_id` (`add_city_id`),
  KEY `add_country_id` (`add_country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `theaters`
--


-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_id` int(11) NOT NULL,
  `seat_id` int(11) NOT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  `paid` tinyint(1) NOT NULL DEFAULT '0',
  `note` varchar(255) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_id`),
  KEY `fk_tickets_schedules1_idx` (`schedule_id`),
  KEY `fk_tickets_seats1_idx` (`seat_id`),
  KEY `reserved` (`reserved`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tickets`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telephone` varchar(15) DEFAULT NULL,
  `add_street` varchar(50) DEFAULT NULL,
  `add_city_id` int(11) DEFAULT NULL,
  `add_country_id` int(11) DEFAULT NULL,
  `lang_id` varchar(10) NOT NULL DEFAULT 'vi_VN',
  `pwd` varchar(45) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `owner_id` int(11) DEFAULT NULL,
  `client_addr` varchar(50) DEFAULT NULL,
  `client_agent` varchar(255) DEFAULT NULL,
  `client_referer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  KEY `admin` (`admin`),
  KEY `deleted` (`deleted`),
  KEY `add_city_id` (`add_city_id`),
  KEY `add_country_id` (`add_country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `sex`, `age`, `email`, `telephone`, `add_street`, `add_city_id`, `add_country_id`, `lang_id`, `pwd`, `date`, `deleted`, `admin`, `owner_id`, `client_addr`, `client_agent`, `client_referer`) VALUES
(1, 'Super Admin', NULL, NULL, 'superadmin', NULL, NULL, NULL, NULL, 'vi_VN', '64d8f814bc23d3396a952b3c76f74373', '2015-06-08 11:32:26', 0, 2, NULL, NULL, NULL, NULL),
(56, 'POUSSIÈRES DE VIE', NULL, NULL, 'info@poussieresdevie.org', '848-38205534', '05Truong Quyen, Q3,HCM', 8, 1, 'vi_VN', '1853e17277276f3e57c0a12c4a1992c7', '2016-03-23 00:00:00', 0, 1, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_theaters`
--

CREATE TABLE IF NOT EXISTS `users_theaters` (
  `users_id` int(11) NOT NULL,
  `theater_id` int(11) NOT NULL,
  PRIMARY KEY (`users_id`,`theater_id`),
  KEY `fk_users_has_theaters_theaters1_idx` (`theater_id`),
  KEY `fk_users_has_theaters_users1_idx` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_theaters`
--


-- --------------------------------------------------------

--
-- Table structure for table `zones`
--

CREATE TABLE IF NOT EXISTS `zones` (
  `zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `schema_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `shape` varchar(45) DEFAULT NULL,
  `coords` varchar(2000) DEFAULT NULL,
  `default_price` decimal(10,0) DEFAULT NULL,
  `seat` tinyint(4) DEFAULT '1',
  `total_ticket` int(11) DEFAULT '0',
  PRIMARY KEY (`zone_id`),
  KEY `fk_zones_schemas2_idx` (`schema_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zones`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `bands`
--
ALTER TABLE `bands`
  ADD CONSTRAINT `bands_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_bands_categories1` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`categorie_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`categorie_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `city_ibfk_1` FOREIGN KEY (`county_id`) REFERENCES `countries` (`county_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `fk_events_bands1` FOREIGN KEY (`band_id`) REFERENCES `bands` (`band_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_events_schemas1` FOREIGN KEY (`schema_id`) REFERENCES `schemas` (`schema_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_events_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`add_city_id`) REFERENCES `city` (`city_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`add_country_id`) REFERENCES `countries` (`county_id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_6` FOREIGN KEY (`order_status`) REFERENCES `order_status` (`order_status_id`),
  ADD CONSTRAINT `orders_ibfk_7` FOREIGN KEY (`delivered_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_orders1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_order_items_tickets1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`ticket_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `fk_schedules_events1` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `schemas`
--
ALTER TABLE `schemas`
  ADD CONSTRAINT `fk_schemas_theaters1` FOREIGN KEY (`theater_id`) REFERENCES `theaters` (`theater_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `seats`
--
ALTER TABLE `seats`
  ADD CONSTRAINT `seats_ibfk_1` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`zone_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `ship_location`
--
ALTER TABLE `ship_location`
  ADD CONSTRAINT `ship_location_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ship_location_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `theaters`
--
ALTER TABLE `theaters`
  ADD CONSTRAINT `theaters_ibfk_1` FOREIGN KEY (`add_city_id`) REFERENCES `city` (`city_id`),
  ADD CONSTRAINT `theaters_ibfk_2` FOREIGN KEY (`add_country_id`) REFERENCES `countries` (`county_id`),
  ADD CONSTRAINT `theaters_ibfk_3` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `fk_tickets_schedules1` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tickets_seats1` FOREIGN KEY (`seat_id`) REFERENCES `seats` (`seat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `users_theaters`
--
ALTER TABLE `users_theaters`
  ADD CONSTRAINT `users_theaters_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `users_theaters_ibfk_2` FOREIGN KEY (`theater_id`) REFERENCES `theaters` (`theater_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `zones`
--
ALTER TABLE `zones`
  ADD CONSTRAINT `fk_zones_schemas2` FOREIGN KEY (`schema_id`) REFERENCES `schemas` (`schema_id`) ON DELETE CASCADE ON UPDATE NO ACTION;
